package by.training.entity;

public class MatrixEmptyState extends MatrixState {
    @Override
    public String matrixToString() {
        return "Matrix is not initialized or empty";
    }
}
