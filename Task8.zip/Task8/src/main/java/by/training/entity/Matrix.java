package by.training.entity;

public interface Matrix {
    void insert(int value);
}
