package by.training.entity;

public abstract class MatrixState {
    public abstract String matrixToString();
}
