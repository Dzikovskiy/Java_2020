package by.training.entity;

public class MatrixInProgressState extends MatrixState {
    @Override
    public String matrixToString() {
        return "Matrix filling in progress";
    }
}
