package by.training.service;

public interface MatrixConfigReader {
    int threadValue();

    int matrixSize();

    void readValues();
}
