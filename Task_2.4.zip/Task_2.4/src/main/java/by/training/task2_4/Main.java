package by.training.task2_4;

import by.training.task2_4.view.MenuView;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        MenuView menuView = new MenuView();
        menuView.menu();
    }
}
